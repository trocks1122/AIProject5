Input# corresponds to Output#: the output is a possible solution to the input, but some inputs can have multiple solutions.
Your program doesn't have to match the output exactly: the order of items / bags can be in any form you want, as long as the
answer is correct. However, the formatting is essential: your program's output file has to follow the standards of the output files here. Even if the autograder only checks the first line of each section, TA's will manually read over the lists to make sure everything checks out, so don't shirk on the rest of the things (though it should be simple enough if you solved the first line correctly).

1-5: Basic Fitting
6-8: Fitting Limits
9-10: Unary Inclusive
11-12: Unary Exclusive
13: Unary In/Exclusive
14-16: Binary Equals
17-18: Binary !Equals
19-20: Binary Equals + Not-Equals
21-22: Binary Mutual Inclusive
23: Basic - Unary
24: Unary - Binary
25: Basic - Binary
26: Huge Log Output W/O some minmaxing