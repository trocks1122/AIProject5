Instructions for running in linux
1) Open terminal
2) cd to Project folder
3) Move input file from Test Inputs and Solutions up to the same file as main.py
4) In terminal do: python main.py input##.txt 
5) Program will run and will print out the output solution
